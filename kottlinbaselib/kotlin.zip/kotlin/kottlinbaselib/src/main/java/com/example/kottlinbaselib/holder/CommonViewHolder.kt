package com.example.kottlinbaselib.holder

class CommonViewHolder {
}