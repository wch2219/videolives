package com.hg.kotlin.api

interface ApiServer {
}