package com.hg.kotlin

import android.app.Application

class MyApplication :Application(){

    override fun onCreate() {
        super.onCreate()


    }
}