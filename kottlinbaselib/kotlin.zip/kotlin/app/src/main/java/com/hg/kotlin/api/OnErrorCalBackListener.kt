package com.hg.kotlin.api

interface OnErrorCalBackListener {
     fun onError(code: Int, mess: String)
}