package com.hg.kotlin.api

class ApiContents {
    companion object {
        val Token: String="token"

    }

}